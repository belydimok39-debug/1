name="Пепел Веймарской республики"
version="0.1.0"
supported_version="1.19.3"
tags={
    "Alternative History"
    "Events"
    "National Focuses"
}
