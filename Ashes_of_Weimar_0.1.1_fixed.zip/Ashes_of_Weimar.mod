name="Пепел Веймарской республики"
path="mod/Ashes_of_Weimar"
version="0.1.0"
supported_version="1.19.3"
tags={ "Alternative History" "Events" "National Focuses" }
